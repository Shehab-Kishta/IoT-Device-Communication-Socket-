#ifndef CLIENT_HPP
#define CLIENT_HPP

#include "../Drivers/Channel/channel.hpp"
#include <boost/asio.hpp>

#endif